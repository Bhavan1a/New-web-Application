import React from 'react'
import FavoritesList from '../components/FavoritesList'


export default function Favorites(){
return (
<div className="container app-container">
<h2>Your Favorites</h2>

<FavoritesList />
</div>
)
}