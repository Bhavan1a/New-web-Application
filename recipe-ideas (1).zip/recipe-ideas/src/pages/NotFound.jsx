import React from 'react'


export default function NotFound(){
return (
<div className="container app-container text-center">
<h2>Page not found</h2>
<p className="text-muted">We couldn't find what you're looking for.</p>
</div>
)
}